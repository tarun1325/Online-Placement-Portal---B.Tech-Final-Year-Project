$(document).ready(function() {
    $("#img1").click(function() {
        $('#desc_exhi_heading').html('Mind Controlled Helicopter');
        $('#desc_exhi_write').html('Write up from first');
        $(".exhi_img_sel").removeClass( "exhi_img_sel" ).addClass( "exhi_img" );
        $('#country').html('united States');
        $('#exhi_flag').html("<img src='{% static 'img/exhibitions/nations/us.jpg' %}' class='flag'>");
        $( this ).removeClass( "exhi_img" ).addClass( "exhi_img_sel" );
    });
    $("#img2").click(function() {
        $('#desc_exhi_heading').html('Face Android');
        $('#desc_exhi_write').html('write first');
        $(".exhi_img_sel").removeClass( "exhi_img_sel" ).addClass( "exhi_img" );
        $('#country').html('Italy');
        $('#exhi_flag').html("<img src='{% static 'img/exhibitions/nations/italy.jpg' %}' class='flag'>");
        $( this ).removeClass( "exhi_img" ).addClass( "exhi_img_sel" );
    });
    $("#img3").click(function() {
        $('#desc_exhi_heading').html('Miniature Models');
        $('#desc_exhi_write').html('write third');
        $(".exhi_img_sel").removeClass( "exhi_img_sel" ).addClass( "exhi_img" );
        $('#country').html('India');
        $('#exhi_flag').html("<img src='{% static 'img/exhibitions/nations/india.jpg' %}' class='flag'>");
        $( this ).removeClass( "exhi_img" ).addClass( "exhi_img_sel" );
    });
    $("#img4").click(function() {
        $('#desc_exhi_heading').html('This.Play 3D');
        $('#desc_exhi_write').html('write first');
        $(".exhi_img_sel").removeClass( "exhi_img_sel" ).addClass( "exhi_img" );
        $('#country').html('Australia');
        $('#exhi_flag').html("<img src='{% static 'img/exhibitions/nations/australia.jpg' %}' class='flag'>");
        $( this ).removeClass( "exhi_img" ).addClass( "exhi_img_sel" );
        $( this ).removeClass( "exhi_img" ).addClass( "exhi_img_sel" );
    });
    $("#img5").click(function() {
        $('#desc_exhi_heading').html('Nao Robot');
        $('#desc_exhi_write').html('write fifth');
        $(".exhi_img_sel").removeClass( "exhi_img_sel" ).addClass( "exhi_img" );
        $('#country').html('New Zealand');
        $('#exhi_flag').html("<img src='{% static 'img/exhibitions/nations/newzealand.jpg' %}' class='flag'>");
        $( this ).removeClass( "exhi_img" ).addClass( "exhi_img_sel" );
    });
    $("#img6").click(function() {
        $('#desc_exhi_heading').html('Paper Tab');
        $('#desc_exhi_write').html('write sixth');
        $(".exhi_img_sel").removeClass( "exhi_img_sel" ).addClass( "exhi_img" );
        $('#country').html('Canada');
        $('#exhi_flag').html("<img src='{% static 'img/exhibitions/nations/canada.jpg' %}' class='flag'>");
        $( this ).removeClass( "exhi_img" ).addClass( "exhi_img_sel" );
    });
    $("#img7").click(function() {
        $('#desc_exhi_heading').html('Talking Robot');
        $('#desc_exhi_write').html('write seventh');
        $(".exhi_img_sel").removeClass( "exhi_img_sel" ).addClass( "exhi_img" );
        $('#country').html('Japan');
        $('#exhi_flag').html("<img src='{% static 'img/exhibitions/nations/japan.jpg' %}' class='flag'>");
        $( this ).removeClass( "exhi_img" ).addClass( "exhi_img_sel" );
    });

    $("#img1").hover(function() {
        $("#img4").css({"z-index": "70"});
        var x = 100;
        for (var i = 1; i < 10; i++) {
            $("#img" + i).css({
                "top": 2 * i + "%",
                "-webkit-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "top": 2 * i + "%",
                "-moz-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "z-index": x
            });
            x = x - 10;
        }
    });
    $("#img2").hover(function() {
        var x = 100;
        for (var i = 2; i < 10; i++) {
            $("#img" + i).css({
                "top": 2 * (i - 1) + "%",
                "-webkit-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "top": 2 * (i - 1) + "%",
                "-moz-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "z-index": x
            });
            x = x - 10;
        }
        var x = 10;
        for (var i = 1; i < 2; i++) {
            $("#img" + i).css({
                "top": 2 * (i + 1) + "%",
                "-webkit-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "top": 2 * (i + 1) + "%",
                "-moz-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "z-index": x
            });
            x = x + 10;
        }
    });
    $("#img3").hover(function() {
        var x = 100;
        for (var i = 3; i < 10; i++) {
            $("#img" + i).css({
                "top": 2 * (i - 2) + "%",
                "-webkit-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "top": 2 * (i - 2) + "%",
                "-moz-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "z-index": x
            });
            x = x - 10;
        }
        var x = 10;
        for (var i = 1; i < 3; i++) {
            $("#img" + i).css({
                "top": 2 * (3 - i + 1) + "%",
                "-webkit-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "top": 2 * (3 - i + 1) + "%",
                "-moz-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "z-index": x
            });
            x = x + 10;
        }
    });
    $("#img4").hover(function() {
        $("#img4").css({
            "z-index": "100"
        });
        var x = 100;
        for (var i = 4; i < 10; i++) {
            $("#img" + i).css({
                "top": 2 * (i - 3) + "%",
                "-webkit-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "top": 2 * (i - 3) + "%",
                "-moz-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "z-index": x
            });
            x = x - 10;
        }
        var x = 10;
        for (var i = 1; i < 4; i++) {
            $("#img" + i).css({
                "top": 2 * (4 - i + 1) + "%",
                "-webkit-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "top": 2 * (4 - i + 1) + "%",
                "-moz-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "z-index": x
            });
            x = x + 10;
        }
    });
    $("#img7").hover(function() {
        $("#img7").css({
            "z-index": "80"
        });
        $("#img6").css({
            "z-index": "70"
        });
        var x = 100;
        for (var i = 7; i < 10; i++) {
            $("#img" + i).css({
                "top": 2 * (i - 7) + "%",
                "-webkit-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "top": 2 * (i - 7) + "%",
                "-moz-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "z-index": x
            });
            x = x - 10;
        }
        var x = 10;
        for (var i = 1; i < 7; i++) {
            $("#img" + i).css({
                "top": 2 * (7 - i + 1) + "%",
                "-webkit-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "top": 2 * (7 - i + 1) + "%",
                "-moz-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "z-index": x
            });
            x = x + 10;
        }
    });
    $("#img6").hover(function() {
        $("#img6").css({
            "z-index": "100"
        });
        //$("#img4").css({"z-index":"40"});
        var x = 100;
        for (var i = 6; i < 10; i++) {
            $("#img" + i).css({
                "top": 2 * (i - 5) + "%",
                "-webkit-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "top": 2 * (i - 5) + "%",
                "-moz-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "z-index": x
            });
            x = x - 10;
        }
        var x = 10;
        for (var i = 1; i < 6; i++) {
            $("#img" + i).css({
                "top": 2 * (6 - i + 1) + "%",
                "-webkit-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "top": 2 * (6 - i + 1) + "%",
                "-moz-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "z-index": x
            });
            x = x + 10;
        }
    });
    $("#img5").hover(function() {
        var x = 100;
        for (var i = 5; i < 10; i++) {
            $("#img" + i).css({
                "top": 2 * (i - 5) + "%",
                "-webkit-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "top": 2 * (i - 5) + "%",
                "-moz-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "z-index": x
            });
            x = x - 10;
        }
        var x = 10;
        for (var i = 1; i < 5; i++) {
            $("#img" + i).css({
                "top": 2 * (5 - i + 1) + "%",
                "-webkit-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "top": 2 * (5 - i + 1) + "%",
                "-moz-transition": "top 0.5s"
            });
            $("#img" + i).css({
                "z-index": x
            });
            x = x + 10;
        }
    });
});